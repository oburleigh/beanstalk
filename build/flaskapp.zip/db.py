from notejam import db

# Create db schema
db.create_all()
